﻿using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.DAL;

namespace Capgemini.GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting OrderDetailss from OrderDetailss collection.
    /// </summary>
    public class OrderDetailsBL : BLBase<OrderDetails>, IOrderDetailsBL, IDisposable
    {
        //fields
        OrderDetailsDALBase OrderDetailsDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public OrderDetailsBL()
        {
            this.OrderDetailsDAL = new OrderDetailsDAL();
        }

        

        /// <summary>
        /// Adds new OrderDetails to OrderDetailss collection.
        /// </summary>
        /// <param name="newOrderDetails">Contains the OrderDetails details to be added.</param>
        /// <returns>Determinates whether the new OrderDetails is added.</returns>
        public async Task<bool> AddOrderDetailsBL(OrderDetails newOrderDetails)
        {
            bool OrderDetailsAdded = false;
            try
            {
                if (await Validate(newOrderDetails))
                {
                    await Task.Run(() =>
                    {
                        this.OrderDetailsDAL.AddOrderDetailsDAL(newOrderDetails);
                        OrderDetailsAdded = true;
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return OrderDetailsAdded;
        }

        

        /// <summary>
        /// Gets OrderDetails based on OrderID.
        /// </summary>
        /// <param name="searchOrderID">Represents OrderID to search.</param>
        /// <returns>Returns OrderID object.</returns>
        public async Task<List<OrderDetails>> GetOrderDetailsByOrderIDBL(Guid searchOrderID)
        {
            List<OrderDetails> matchingOrderDetails = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingOrderDetails = OrderDetailsDAL.GetOrderDetailsByOrderIDDAL(searchOrderID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetails;
        }

        /// <summary>
        /// Gets OrderDetails based on OrderDetailsName.
        /// </summary>
        /// <param name="searchProductID">Represents OrderDetailsName to search.</param>
        /// <returns>Returns OrderDetails object.</returns>
        public async Task<List<OrderDetails>> GetOrderDetailsByProductIDBL(Guid searchProductID)
        {
            List<OrderDetails> matchingOrderDetailss = new List<OrderDetails>();
            try
            {
                await Task.Run(() =>
                {
                    matchingOrderDetailss = OrderDetailsDAL.GetOrderDetailsByProductIDDAL(searchProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingOrderDetailss;
        }


        /// <summary>
        /// Deletes OrderDetails based on OrderDetailsID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderDetailsID to delete.</param>
        /// /// <param name="deleteProductID">Represents OrderDetailsID to delete.</param>
        /// <returns>Determinates whether the existing OrderDetails is updated.</returns>
        public async Task<bool> DeleteOrderDetailsBL(Guid deleteOrderID,Guid deleteProductID)
        {
            bool OrderDetailsDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    OrderDetailsDeleted = OrderDetailsDAL.DeleteOrderDetailsDAL(deleteOrderID,deleteProductID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return OrderDetailsDeleted;
        }

        

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((OrderDetailsDAL)OrderDetailsDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                //OrderDetailsDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
               // OrderDetailsDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
