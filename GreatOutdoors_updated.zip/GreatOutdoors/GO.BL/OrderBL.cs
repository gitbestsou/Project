﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.DataAccessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.Exceptions;
using System.Reflection;
using System.Text.RegularExpressions;
using GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Contracts.DALContracts;
using GreatOutdoors.Helpers.ValidationAttributes;
using GreatOutdoorOrder.BusinessLayer;
using GreatOutdoors.Exceptions;

namespace GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class OrderBL : BLBase<Order>, IOrdersBL, IDisposable
    {
        //fields
        OrdersDALBase orderDAL;

        /// <summary>
        /// Constructor
        /// </summary>
        
        public OrderBL()
        {
            this.orderDAL = new OrderDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected  async override Task<bool> Validate(Order entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //OrderID is Unique
            var existingObject = await SearchOrderBL(entityObject.OrderID);
            if (existingObject != null && existingObject?.OrderID != entityObject.OrderID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Order {entityObject.OrderID} already exists");
            }

            if (valid == false)
                throw new Exception(sb.ToString());
            return valid;
        }


        //private static bool ValidateOrder(Order order)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    bool validOrder = true;
        //    if (order.OrderID <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Invalid Guest ID");

        //    }
        //    if (order.RetailerID <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.SalesmanID <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.ProductID <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.Quantity <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.SellingPrice <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.TotalAmount <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.AmountPayable <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.FinalDelieveryAddress == string.Empty)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.ChannelOfSale == string.Empty)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.Status == string.Empty)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }
        //    if (order.CategoryID <= 0)
        //    {
        //        validOrder = false;
        //        sb.Append(Environment.NewLine + "Guest Name Required");

        //    }


        //    if (validOrder == false)
        //        throw new OrderException(sb.ToString());
        //    return validOrder;
        //}

        public async Task<bool> AddOrderBL(Order newOrder)
        {
            bool orderAdded = false;
            try
            {
                if (await Validate(newOrder))
                {
                    await Task.Run(() =>
                    {
                        this.orderDAL.AddOrderDAL(newOrder);
                        orderAdded = true;
                        Serialize();
                    });
                   
                }
            }
            catch (Exception ex)
            {
                throw;
            }
           return orderAdded;
        }

        public async Task<List<Order>> GetAllOrdersBL()
        {
            List<Order> orderList = null;
            try
            {
                await Task.Run(() =>
                {
                    orderList = orderDAL.GetAllOrdersDAL();
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return orderList;
        }

        public async  Task<Order> SearchOrderBL(int searchOrderID)
        {
            Order searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.SearchOrderDAL(searchOrderID);
                });
               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async  Task<List<Order>> SearcOrderbyRetailerIDBL(int retailerID)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByRetailerIDDAL(retailerID);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> SearchOrderByCategoryIDBL(int categoryID)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByCategoryIDDAL(categoryID);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> SearchOrderBySalesmanIDBL(int salesmanID) // to delete
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderBySalesmanIDDAL(salesmanID);
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> SearchOrderByOfflineBL(string channelofsale) // enum -channel of sale
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByOfflineDAL(channelofsale);
                }); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchOrder;

        }

        public async Task<List<Order>> SearchOrderForOfflineBL()
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderForOfflineSaleDAL();
                });  
            }
            catch (Exception ex)
            {
                throw ex;
            }
           
            return searchOrder;

        }

        public async Task<List<Order>> SearchOrderByOnlineBL(string channelofsale)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByOnlineDAL(channelofsale);
                });
                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }

        public async Task<List<Order>> GetOrderByStatusBL(string status)
        {
            List<Order> searchOrder = null;
            try
            {
                await Task.Run(() =>
                {
                    searchOrder = orderDAL.GetOrderByStatusDAL(status);
                }); 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
            return searchOrder;

        }


        public async Task<bool> UpdateOrderBL(Order updateOrder)
        {
            bool orderUpdated = false;
            try
            {
                if ((await Validate(updateOrder)) && (await SearchOrderBL(updateOrder.OrderID)) != null)
                {
                    this.orderDAL.UpdateOrderDAL(updateOrder);
                    orderUpdated = true;
                    Serialize();
                }
                
            }
            catch (Exception ex)
            {
                throw;
            }
            

            return orderUpdated;
        }

        /// <summary>
         /// Disposes DAL object(s).
         /// </summary>
        public void Dispose()
        {
            ((OrderDAL)orderDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                OrderDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                OrderDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}