import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ReturnComponent } from './Returns/returns.component';

const routes: Routes = [

  { path: "returns", component: ReturnComponent },        
  { path: "**", redirectTo: 'returns', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReturnRoutingModule
{
}
