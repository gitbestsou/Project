import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ReturnDetail } from '../Models/return-detail';

@Injectable({
  providedIn: 'root'
})
export class ReturnDetailsService {
  constructor(private httpClient: HttpClient) {
  }

  AddReturnDetail(returndetail: ReturnDetail): Observable<boolean> {
    returndetail.creationDateTime = new Date().toLocaleDateString();
    returndetail.lastModifiedDateTime = new Date().toLocaleDateString();
    returndetail.returnDetailID = this.uuidv4();
    return this.httpClient.post<boolean>(`/api/returndetails`, returndetail);
  }

  UpdateReturnDetail(returndetail: ReturnDetail): Observable<boolean> {
    returndetail.lastModifiedDateTime = new Date().toLocaleDateString();
    return this.httpClient.put<boolean>(`/api/returndetails`, returndetail);
  }

  DeleteReturnDetail(returnDetailID: string, id: number): Observable<boolean> {
    return this.httpClient.delete<boolean>(`/api/returndetails/${id}`);
  }

  GetAllReturnDetails(): Observable<ReturnDetail[]> {
    return this.httpClient.get<ReturnDetail[]>(`/api/returndetails`);
  }

  GetReturnDetailByReturnDetailID(ReturnDetailID: number): Observable<ReturnDetail> {
    return this.httpClient.get<ReturnDetail>(`/api/returndetails?returndetailID=${ReturnDetailID}`);
  }

  GetReturnDetailByReturnID(ReturnID: number): Observable<ReturnDetail> {
    return this.httpClient.get<ReturnDetail>(`/api/returndetails?returnID=${ReturnID}`);
  }

  GetReturnDetailByOrderDetailID(OrderDetailID: number): Observable<ReturnDetail> {
    return this.httpClient.get<ReturnDetail>(`/api/returndetails?returndetailID=${OrderDetailID}`);
  }


  uuidv4() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  }
}



