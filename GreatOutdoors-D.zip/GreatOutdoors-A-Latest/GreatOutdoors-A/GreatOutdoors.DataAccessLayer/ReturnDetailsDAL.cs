﻿using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.DAL
{

    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting OrderDetailss from OrderDetailss collection.
    /// </summary>
    public class ReturnDetailsDAL : ReturnDetailsDALBase, IDisposable
    {
        /// <summary>
        /// Adds new OrderDetails to OrderDetails collection.
        /// </summary>
        /// <param name="newReturnDetails">Contains the OrderDetails details to be added.</param>
        /// <returns>Determinates whether the new OrderDetails is added.</returns>
        public override bool AddReturnDetailsDAL(ReturnDetails newReturnDetails)
        {
            bool returnDetailsAdded = false;
            try
            {
                newReturnDetails.ReturnDetailID = Guid.NewGuid();

                ReturnDetailsList.Add(newReturnDetails);
                returnDetailsAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return returnDetailsAdded;
        }


        /// <summary>
        /// Gets OrderDetails based on OrderID.
        /// </summary>
        /// <param name="searchReturnID">Represents OrderDetailsID to search.</param>
        /// <returns>Returns List of OrderDetails object.</returns>
        public override List<ReturnDetails> GetReturnDetailsByReturnIDDAL(Guid searchReturnID)
        {
            List<ReturnDetails> matchingReturnDetails = null;
            try
            {
                //Find OrderDetails based on searchOrderDetailsID
                matchingReturnDetails = ReturnDetailsList.FindAll(
                    (item) => { return item.ReturnDetailID == searchReturnID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReturnDetails;
        }

        /// <summary>
        /// Gets OrderDetails based on ProductID.
        /// </summary>
        /// <param name="searchProductID">Represents OrderDetailsID to search.</param>
        /// <returns>Returns OrderDetails object.</returns>
        public override List<ReturnDetails> GetReturnDetailsByProductIDDAL(Guid searchProductID)
        {
            List<ReturnDetails> matchingReturnDetails = null;
            try
            {
                //Find OrderDetails based on searchOrderDetailsID
                matchingReturnDetails = ReturnDetailsList.FindAll(
                    (item) => { return item.ReturnDetailID == searchProductID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingReturnDetails;
        }



        /// <summary>
        /// Deletes OrderDetails based on OrderID and ProductID.
        /// </summary>
        /// <param name="deleteOrderID">Represents OrderDetailsID to delete.</param>
        /// <param name="deleteProductID">Represents OrderDetailsID to delete.</param>
        /// <returns>Determinates whether the existing OrderDetails is updated.</returns>
        public override bool DeleteReturnDetailsDAL(Guid deleteReturnID, Guid deleteProductID)
        {
            bool returnDeleted = false;
            try
            {

                ReturnDetails matchingReturnDetails = ReturnDetailsList.Find(
                    (item) => { return item.ReturnDetailID == deleteReturnID && item.ProductID == deleteProductID; }
                );

                if (matchingReturnDetails != null)
                {
                    //Delete OrderDetails from the collection
                    ReturnDetailsList.Remove(matchingReturnDetails);
                    returnDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return returnDeleted;
        }





        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}

