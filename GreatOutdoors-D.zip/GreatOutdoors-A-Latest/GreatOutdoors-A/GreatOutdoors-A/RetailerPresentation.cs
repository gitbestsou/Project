﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class RetailerPresentation
    {
        /// <summary>
        /// Menu for Retailer
        /// </summary>
        /// <returns></returns>
        public static async Task<int> RetailerMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***************RETAILER***********");
                WriteLine("1. Initiate Order");
                WriteLine("2. View My Orders");
                WriteLine("3. Return Order");
                WriteLine("4. Cancel Order ");
                WriteLine("5. View My Returns");
                WriteLine("-----------------------");
                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("Choice: ");

                //Get current Retailer details
                IRetailerBL currRetailerBL = new RetailerBL();
                Retailer retailer = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);

                Guid currentRetailerID = retailer.RetailerID;
               

                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            //Call Method for placing order
                            await MakeOrder.ViewProducts();//Current Retailer ID

                            break;
                        case 2:
                            //Call Method for viewing retailer orders
                            using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                Console.WriteLine("#\tOrderID\tQuantity\tTotal Amount\tOrder Date\tCurrent Status\tShipping Address");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}\t{order.CurrentStatus}\t{order.ShippingAddress}");

                                    }
                                }

                                // Select order from list
                                Console.WriteLine("Please Select the Order  : ");
                                int orderSelection = int.Parse(Console.ReadLine());
                                using (IOrderDetailsBL accessOrderDetails = new OrderDetailsBL())
                                {
                                    List<OrderDetail> orderDetail = new List<OrderDetail>();
                                    orderDetail = await accessOrderDetails.GetOrderDetailsByOrderIDBL(orderHistory[orderSelection - 1].OrderID);

                                    // Printing products in the order
                                    Console.WriteLine("Products in this Order: ");
                                    if (orderDetail != null && orderDetail?.Count > 0)
                                    {
                                        Console.WriteLine(".......................");
                                        int serial = 0;
                                        foreach (var product in orderDetail)
                                        {
                                            serial++;
                                            ProductBL productBL = new ProductBL();
                                            string productName = (await productBL.GetProductByProductIDBL(product.ProductID)).ProductName;
                                            Console.WriteLine($"{serial}\t{productName}\t{product.Quantity}\t{product.UnitPrice}");
                                        }
                                    }
                                }

                            }
                            break;
                        case 3:
                            await PlaceReturn.ReturnRequest(currentRetailerID);
                            /*using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                                    }
                                }
                                WriteLine("Select Order to Return: ");
                                int SNo = int.Parse(ReadLine())-1;
                                orderHistory[SNo].CurrentStatus = Status.Return;
                                Console.WriteLine("Return Generated");
                            }*/
                            break;
                        case 4:
                            //Call Method for Cancelling an order
                            await CancelOrder.CancelRequest(currentRetailerID);
                            break;

                        case 5:
                            await PlaceReturn.ViewReturns(currentRetailerID);
                            break;

                        case 0: break;
                        case -1: break;
                        default:
                            WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }





        
    }
}



