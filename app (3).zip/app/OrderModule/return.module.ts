import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { ReturnComponent } from './Returns/returns.component';
import { ReturnRoutingModule } from './return-routing.module';
/*import { AdminHomeComponent } from './admin-home/admin-home.component';
import { SuppliersComponent } from './suppliers/suppliers.component';
import { AdminRoutingModule } from './admin-routing.module';
import { NewOrderComponent } from './new-order/new-order.component';*/


/*
  
*
* Developer Name: Sourav Maji
  * Use Case - 1. Return a product from Orders which has been delivered
2. Cancel a product from Orders which has been placed but not deliverd
Creation Date - 10 / 10 / 2019
Last Modified Date - 12 / 10 / 2019

*/



@NgModule({
  declarations: [

    ReturnComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ReturnRoutingModule
  ],
  exports: [
    ReturnRoutingModule,
    ReturnComponent
  ]
})
export class ReturnModule { }

