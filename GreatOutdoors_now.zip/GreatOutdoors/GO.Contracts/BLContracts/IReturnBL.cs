﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GreatOutdoors.Entities;
namespace GreatOutdoors.Contracts.BLContracts
{
    public interface IReturnBL:IDisposable
    {
        Task<bool> AddReturnBL(Return newReturn);
        Task<List<Return>> GetAllReturnsBL();
        Task<Return> GetReturnByReturnIDBL(Guid searchReturnID);
        Task<bool> UpdateReturnBL(Return updateReturn);
        Task<bool> DeleteReturnBL(Guid deleteReturnID);

    }
}
