﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GreatOutdoors.Entities;

namespace GreatOutdoors.Contracts.BLContracts
{
    public interface ISalesManBL : IDisposable
    {
        Task<bool> AddSalesManBL(SalesMan newSalesMan);
        Task<List<SalesMan>> GetAllSalesMansBL();
        Task<SalesMan> GetSalesManBySalesManIDBL(Guid searchSalesManID);
        Task<List<SalesMan>> GetSalesMansByNameBL(string salesManName);
        Task<SalesMan> GetSalesManByEmailBL(string email);
        Task<SalesMan> GetSalesManByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateSalesManBL(SalesMan updateSalesMan);
        Task<bool> UpdateSalesManPasswordBL(SalesMan updateSalesMan);
        Task<bool> DeleteSalesManBL(Guid deleteSalesManID);

        Task<bool> AddSalesBL(Guid saleOrderID, Guid salesManID);
        Task<List<Guid>>  GetSalesBL(Guid salesManID);
        Task<Order> SearchSalesBL(Guid searchSalesID, Guid salesManID);
        Task<bool> AddSalesOrderBL(Order newOrder, Guid salesManID);
        Task<List<Order>> ViewActiveOrdersBL();
        Task<bool> AcceptOrderForSaleBL(Guid activeOrderID);
        Task<bool> ModifySalesOrderBL(Order updatedOrder);
        Task<bool> ConfirmSalesOrderBL(Guid confirmOrderID, Guid salesManID);





    }
}


