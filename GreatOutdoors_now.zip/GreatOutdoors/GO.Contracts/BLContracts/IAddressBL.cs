﻿using GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GreatOutdoors.Contracts.BLContracts
{
    public interface IAddressBL
    {
        Task<bool> AddAddressBL(Address_Entities newAddress);
        Task<List<Address_Entities>> GetAllAddressBL();
        Task<Address_Entities> GetAddressByAddressIDBL(Guid searchAddressID);
        Task<bool> UpdateAddressBL(Address_Entities updateAddress);
        Task<bool> DeleteAddressBL(Guid deleteAddressID);
    }
}