﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GreatOutdoors.Entities;

namespace GreatOutdoors.Contracts.BLContracts
{
    public interface IProductBL : IDisposable
    {
        Task<bool> AddProductBL(Product newProduct);
        Task<List<Product>> GetAllProductsBL();
        Task<Product> GetProductByProductIDBL(Guid searchProductID);
        Task<List<Product>> GetProductsByNameBL(string ProductName);
        Task<Product> GetProductByCategoryBL(Category CategoryName);
        Task<bool> UpdateProductBL(Product updateProduct);
        Task<bool> DeleteProductBL(Guid deleteProductID);
        Task<bool> UpdateProductStockDAL(Product updateProduct);
        Task<bool> SelectProductQuantityDAL(Product updateProduct);
    }
}


