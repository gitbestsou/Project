﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using GreatOutdoors.Entities;

namespace GreatOutdoors.Contracts.BLContracts
{
    public interface IAdminBL : IDisposable
    {
        Task<Admin_Entities> GetAdminByEmailAndPasswordBL(string email, string password);
        Task<bool> UpdateAdminBL(Admin_Entities updateAdmin);
        Task<bool> UpdateAdminPasswordBL(Admin_Entities updateAdmin);
    }
}
