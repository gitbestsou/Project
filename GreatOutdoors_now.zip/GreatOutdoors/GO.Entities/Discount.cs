﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    /// <summary>
    /// Interface for Discount Entity
    /// </summary>
    public interface IDiscount
    {
        Guid DiscountID { get; set; }
        Guid RetailerID { get; set; }
        double RetailerDiscount { get; set; }
        double CategoryDiscount { get; set; }
        DateTime CreationDateTime { get; set; }
        DateTime LastModifiedDateTime { get; set; }
    }

    /// <summary>
    /// Represents Discount
    /// </summary>
    public class Discount: IDiscount
    {
        /*Auto-Implemented Properties*/
        [Required("OrderID can't be empty")]
        public Guid OrderID { get; set; }

        [Required("RetailerID can't be empty")]
        public Guid RetailerID { get; set; }

        [Required("Retailer discount can't be empty")]
        public double RetailerDiscount { get; set; }

        [Required("Category discount can't be empty")]
        public double CategoryDiscount { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public Discount()
        {
            OrderID = default(Guid);
            RetailerID = default(Guid);
            RetailerDiscount = default(double);
            CategoryDiscount = default(double);
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }
    }
}
