﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    public enum ReasonOfReturn { Wrong,Incomplete}
    //IReturn interface
    public interface Return
    {
        Guid ReturnId { get; set; }
        ReasonOfReturn reasonOfReturn { get; set; }

    }



    public class Return
    {
        [Required("Distributor ID can't be blank.")]
        public Guid ReturnID { get; set; }

        [Required("ReasonIncomplete cannot be blank")]
        //change bool to enum
        public bool ReasonIncomplete;

        public Guid ProductID { get; set; }
        
        [Required("Return value cannot be blank")]
        public double ReturnAmount;

        [Required("Return quantity cannot be blank")]
        public int ReturnQuantity;

        public double UnitPrice { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }


        public Return()
        {
            ReturnID = default(Guid);
            ReasonIncomplete = false;
            ReturnQuantity = 0;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);
        }


    }

}


