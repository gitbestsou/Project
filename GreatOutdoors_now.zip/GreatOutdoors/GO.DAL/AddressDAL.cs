﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers;
using GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Entities;

namespace GreatOutdoors.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting admins from Admins collection.
    /// </summary>
    public class AddressDAL : AddressDALBase, IDisposable
    {
        /// <summary>
        /// Constructor of AddressDAL
        /// </summary>
        public AddressDAL()
        {
            Serialize();
            Deserialize();
        }

        /// <summary>
        /// Adds new address to Address collection.
        /// </summary>
        /// <param name="newAddress">Contains the address details to be added.</param>
        /// <returns>Determinates whether the new address is added.</returns>
        public override bool AddAddressDAL(Address_Entities newAddress)
        {
            bool addressAdded = false;
            try
            {
                newAddress.AddressID = Guid.NewGuid();
                newAddress.CreationDateTime = DateTime.Now;
                newAddress.LastModifiedDateTime = DateTime.Now;
                addressList.Add(newAddress);
                addressAdded = true;
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return addressAdded;
        }
        /// <summary>
        /// Gets all addresses from the collection.
        /// </summary>
        /// <returns>Returns list of all distributors.</returns>
        public override List<Address_Entities> GetAllAddressDAL()
        {
            return addressList;
        }
        /// <summary>
        /// Gets distributor based on DistributorID.
        /// </summary>
        /// <param name="searchAddressID">Represents DistributorID to search.</param>
        /// <returns>Returns Distributor object.</returns>
        public override Address_Entities GetAddressByAddressIDDAL(Guid searchAddressID)
        {
            Address_Entities matchingAddress = null;
            try
            {
                //Find Address based on searchAddressID
                matchingAddress = addressList.Find(
                    (item) => { return item.AddressID == searchAddressID; }
                );
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return matchingAddress;
        }

        /// <summary>
        /// Updates address based on AddressID.
        /// </summary>
        /// <param name="updateAddress">Represents Address details including AddressID, Line1, etc.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override bool UpdateAddressDAL(Address_Entities updateAddress)
        {
            bool addressUpdated = false;
            try
            {
                //Find address based on AddressID
                Address_Entities matchingAddress = GetAddressByAddressIDDAL(updateAddress.AddressID);

                if (matchingAddress != null)
                {
                    //Update address details
                    ReflectionHelpers.CopyProperties(updateAddress, matchingAddress, new List<string>() { "Line1", "Line2", "City", "Pincode", "State", "MobileNo" });
                    matchingAddress.LastModifiedDateTime = DateTime.Now;

                    addressUpdated = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return addressUpdated;

        }

        /// <summary>
        /// Deletes address based on AddressID.
        /// </summary>
        /// <param name="deleteAddressID">Represents AddressID to delete.</param>
        /// <returns>Determinates whether the existing address is updated.</returns>
        public override bool DeleteAddressDAL(Guid deleteAddressID)
        {
            bool addressDeleted = false;
            try
            {
                Address_Entities matchingAddress = null;
                //Find Address based on searchAddressID
                matchingAddress = addressList.Find(
                   (item) => { return item.AddressID == deleteAddressID; }
               );

                if (matchingAddress != null)
                {
                    //Delete Address for collection
                    addressList.Remove(matchingAddress);
                    addressDeleted = true;
                }
            }
            catch (GreatOutdoorsException ex)
            {
                throw new GreatOutdoorsException(ex.Message);
            }
            return addressDeleted;

        }

        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}
