﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using GreatOutdoors.Contracts.DALContracts;
using GreatOutdoors.Entities;
using GreatOutdoors.Exceptions;
using GreatOutdoors.Helpers;

namespace GreatOutdoors.DataAccessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting SalesMans from SalesMans collection.
    /// </summary>
    public class SalesManDAL : SalesManDALBase, IDisposable
    {
        /// <summary>
        /// Adds new SalesMan to SalesMans collection.
        /// </summary>
        /// <param name="newSalesMan">Contains the SalesMan details to be added.</param>
        /// <returns>Determinates whether the new SalesMan is added.</returns>
        public override bool AddSalesManDAL(SalesMan newSalesMan)
        {
            bool SalesManAdded = false;
            try
            {
                newSalesMan.SalesManID = Guid.NewGuid();
                newSalesMan.CreationDateTime = DateTime.Now;
                newSalesMan.LastModifiedDateTime = DateTime.Now;
                SalesManList.Add(newSalesMan);
                SalesManAdded = true;
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManAdded;
        }

        /// <summary>
        /// Gets all SalesMans from the collection.
        /// </summary>
        /// <returns>Returns list of all SalesMans.</returns>
        public override List<SalesMan> GetAllSalesMansDAL()
        {
            return SalesManList;
        }

        /// <summary>
        /// Gets SalesMan based on SalesManID.
        /// </summary>
        /// <param name="searchSalesManID">Represents SalesManID to search.</param>
        /// <returns>Returns SalesMan object.</returns>
        public override SalesMan GetSalesManBySalesManIDDAL(Guid searchSalesManID)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                //Find SalesMan based on searchSalesManID
                matchingSalesMan = SalesManList.Find(
                    (item) => { return item.SalesManID == searchSalesManID; }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Gets SalesMan based on SalesManName.
        /// </summary>
        /// <param name="SalesManName">Represents SalesManName to search.</param>
        /// <returns>Returns SalesMan object.</returns>
        public override List<SalesMan> GetSalesMansByNameDAL(string SalesManName)
        {
            List<SalesMan> matchingSalesMans = new List<SalesMan>();
            try
            {
                //Find All SalesMans based on SalesManName
                matchingSalesMans = SalesManList.FindAll(
                    (item) => { return item.SalesManName.Equals(SalesManName, StringComparison.OrdinalIgnoreCase); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMans;
        }

        /// <summary>
        /// Gets SalesMan based on email.
        /// </summary>
        /// <param name="email">Represents SalesMan's Email Address.</param>
        /// <returns>Returns SalesMan object.</returns>
        public override SalesMan GetSalesManByEmailDAL(string email)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                //Find SalesMan based on Email and Password
                matchingSalesMan = SalesManList.Find(
                    (item) => { return item.Email.Equals(email); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Gets SalesMan based on Email and Password.
        /// </summary>
        /// <param name="email">Represents SalesMan's Email Address.</param>
        /// <param name="password">Represents SalesMan's Password.</param>
        /// <returns>Returns SalesMan object.</returns>
        public override SalesMan GetSalesManByEmailAndPasswordDAL(string email, string password)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                //Find SalesMan based on Email and Password
                matchingSalesMan = SalesManList.Find(
                    (item) => { return item.Email.Equals(email) && item.Password.Equals(password); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Updates SalesMan based on SalesManID.
        /// </summary>
        /// <param name="updateSalesMan">Represents SalesMan details including SalesManID, SalesManName etc.</param>
        /// <returns>Determinates whether the existing SalesMan is updated.</returns>
        public override bool UpdateSalesManDAL(SalesMan updateSalesMan)
        {
            bool SalesManUpdated = false;
            try
            {
                //Find SalesMan based on SalesManID
                SalesMan matchingSalesMan = GetSalesManBySalesManIDDAL(updateSalesMan.SalesManID);

                if (matchingSalesMan != null)
                {
                    //Update SalesMan details
                    ReflectionHelpers.CopyProperties(updateSalesMan, matchingSalesMan, new List<string>() { "SalesManName", "SalesManMobile", "Email" });
                    matchingSalesMan.LastModifiedDateTime = DateTime.Now;

                    SalesManUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManUpdated;
        }

        /// <summary>
        /// Deletes SalesMan based on SalesManID.
        /// </summary>
        /// <param name="deleteSalesManID">Represents SalesManID to delete.</param>
        /// <returns>Determinates whether the existing SalesMan is updated.</returns>
        public override bool DeleteSalesManDAL(Guid deleteSalesManID)
        {
            bool SalesManDeleted = false;
            try
            {
                //Find SalesMan based on searchSalesManID
                SalesMan matchingSalesMan = SalesManList.Find(
                    (item) => { return item.SalesManID == deleteSalesManID; }
                );

                if (matchingSalesMan != null)
                {
                    //Delete SalesMan from the collection
                    SalesManList.Remove(matchingSalesMan);
                    SalesManDeleted = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManDeleted;
        }

        /// <summary>
        /// Updates SalesMan's password based on SalesManID.
        /// </summary>
        /// <param name="updateSalesMan">Represents SalesMan details including SalesManID, Password.</param>
        /// <returns>Determinates whether the existing SalesMan's password is updated.</returns>
        public override bool UpdateSalesManPasswordDAL(SalesMan updateSalesMan)
        {
            bool passwordUpdated = false;
            try
            {
                //Find SalesMan based on SalesManID
                SalesMan matchingSalesMan = GetSalesManBySalesManIDDAL(updateSalesMan.SalesManID);

                if (matchingSalesMan != null)
                {
                    //Update SalesMan details
                    ReflectionHelpers.CopyProperties(updateSalesMan, matchingSalesMan, new List<string>() { "Password" });
                    matchingSalesMan.LastModifiedDateTime = DateTime.Now;

                    passwordUpdated = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Adds new Sales to SalesMan's sale id collection.
        /// </summary>
        /// <param name="saleOrderID">Contains the Sale Order ID  to be added.</param>
        /// <param name="salesManID">Contains the SalesMan ID  who's sale history is to be updated.</param>
        /// <returns>Determines whether the new Sale is added.</returns>
        public override bool AddSalesDAL(Guid saleOrderID, Guid salesManID)
        {
            bool SaleAdded = false;
            try
            {
                //Find SalesMan based on SalesManID
                SalesMan matchingSalesMan = GetSalesManBySalesManIDDAL(salesManID);

                if (matchingSalesMan != null)
                {
                    //Add Sale order id to list of saleids 
                    matchingSalesMan.Add(saleOrderID);
                    matchingSalesMan.LastModifiedDateTime = DateTime.Now;

                    SaleAdded = true;
                }
                
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManAdded;
        }
        /// <summary>
        /// Gets the sale ids of all the sales of a salesman using his ID.
        /// </summary>
        /// <param name="salesManID">Contains the SalesMan ID  who's sale history is to be viewed.</param>
        /// <returns>List list of salesids of salesman.</returns>
        public override List<Guid> GetSalesHistoryDAL(Guid salesManID)
        {
            List<Guid> sales = null;
            try
            {
                //Find SalesMan based on SalesManID
                SalesMan matchingSalesMan = GetSalesManBySalesManIDDAL(salesManID);

                if (matchingSalesMan != null)
                {
                    //Copy to sales
                    sales = matchingSalesMan.SalesIDs;
                }

            }
            catch (Exception)
            {
                throw;
            }
            return sales;

        }

        /// <summary>
        /// Gets the sale ids of all the sales of a salesman using his ID.
        /// </summary>
        /// <param name="salesManID">Contains the SalesMan ID  who's sale history is to be searched.</param>
        /// <param name="searchSalesID">Contains the sale ID  to be searched.</param>
        /// <returns>Determines whether sale id is found or not.</returns>

        public override bool SearchSalesDAL(Guid searchSalesID, Guid salesManID)
        {
            bool saleIDFound = false;
            try
            {
                //Find SalesMan based on SalesManID
                SalesMan matchingSalesMan = GetSalesManBySalesManIDDAL(salesManID);

                if (matchingSalesMan != null)
                {
                    //Find saleID
                    Guid saleID = matchingSalesMan.SalesIDs.Find(
                    (item) => { return item == searchSalesID; });
                    if (saleID != null)
                        saleIDFound = true;
                }

            }
            catch (Exception)
            {
                throw;
            }
            return saleID;

        }
        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}



