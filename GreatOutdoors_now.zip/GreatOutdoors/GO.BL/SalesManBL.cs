﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.Contracts.DALContracts;
using GreatOutdoors.DataAccessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.Exceptions;
using GreatOutdoors.Helpers.ValidationAttributes;

namespace GreatOutdoors.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for inserting, updating, deleting SalesMans from SalesMans collection.
    /// </summary>
    public class SalesManBL : BLBase<SalesMan>, ISalesManBL, IDisposable
    {
        //fields
        SalesManDALBase SalesManDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public SalesManBL()
        {
            this.SalesManDAL = new SalesManDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(SalesMan entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Email is Unique
            var existingObject = await GetSalesManByEmailBL(entityObject.Email);
            if (existingObject != null && existingObject?.SalesManID != entityObject.SalesManID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Email {entityObject.Email} already exists");
            }

            if (valid == false)
                throw new InventoryException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new SalesMan to SalesMans collection.
        /// </summary>
        /// <param name="newSalesMan">Contains the SalesMan details to be added.</param>
        /// <returns>Determinates whether the new SalesMan is added.</returns>
        public async Task<bool> AddSalesManBL(SalesMan newSalesMan)
        {
            bool SalesManAdded = false;
            try
            {
                if (await Validate(newSalesMan))
                {
                    await Task.Run(() =>
                    {
                        this.SalesManDAL.AddSalesManDAL(newSalesMan);
                        SalesManAdded = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManAdded;
        }

        /// <summary>
        /// Gets all SalesMans from the collection.
        /// </summary>
        /// <returns>Returns list of all SalesMans.</returns>
        public async Task<List<SalesMan>> GetAllSalesMansBL()
        {
            List<SalesMan> SalesMansList = null;
            try
            {
                await Task.Run(() =>
                {
                    SalesMansList = SalesManDAL.GetAllSalesMansDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return SalesMansList;
        }

        /// <summary>
        /// Gets SalesMan based on SalesManID.
        /// </summary>
        /// <param name="searchSalesManID">Represents SalesManID to search.</param>
        /// <returns>Returns SalesMan object.</returns>
        public async Task<SalesMan> GetSalesManBySalesManIDBL(Guid searchSalesManID)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesMan = SalesManDAL.GetSalesManBySalesManIDDAL(searchSalesManID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Gets SalesMan based on SalesManName.
        /// </summary>
        /// <param name="SalesManName">Represents SalesManName to search.</param>
        /// <returns>Returns SalesMan object.</returns>
        public async Task<List<SalesMan>> GetSalesMansByNameBL(string SalesManName)
        {
            List<SalesMan> matchingSalesMans = new List<SalesMan>();
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesMans = SalesManDAL.GetSalesMansByNameDAL(SalesManName);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMans;
        }

        /// <summary>
        /// Gets SalesMan based on Email and Password.
        /// </summary>
        /// <param name="email">Represents SalesMan's Email Address.</param>
        /// <returns>Returns SalesMan object.</returns>
        public async Task<SalesMan> GetSalesManByEmailBL(string email)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesMan = SalesManDAL.GetSalesManByEmailDAL(email);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Gets SalesMan based on Password.
        /// </summary>
        /// <param name="email">Represents SalesMan's Email Address.</param>
        /// <param name="password">Represents SalesMan's Password.</param>
        /// <returns>Returns SalesMan object.</returns>
        public async Task<SalesMan> GetSalesManByEmailAndPasswordBL(string email, string password)
        {
            SalesMan matchingSalesMan = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesMan = SalesManDAL.GetSalesManByEmailAndPasswordDAL(email, password);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return matchingSalesMan;
        }

        /// <summary>
        /// Updates SalesMan based on SalesManID.
        /// </summary>
        /// <param name="updateSalesMan">Represents SalesMan details including SalesManID, SalesManName etc.</param>
        /// <returns>Determinates whether the existing SalesMan is updated.</returns>
        public async Task<bool> UpdateSalesManBL(SalesMan updateSalesMan)
        {
            bool SalesManUpdated = false;
            try
            {
                if ((await Validate(updateSalesMan)) && (await GetSalesManBySalesManIDBL(updateSalesMan.SalesManID)) != null)
                {
                    this.SalesManDAL.UpdateSalesManDAL(updateSalesMan);
                    SalesManUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManUpdated;
        }

        /// <summary>
        /// Deletes SalesMan based on SalesManID.
        /// </summary>
        /// <param name="deleteSalesManID">Represents SalesManID to delete.</param>
        /// <returns>Determinates whether the existing SalesMan is updated.</returns>
        public async Task<bool> DeleteSalesManBL(Guid deleteSalesManID)
        {
            bool SalesManDeleted = false;
            try
            {
                await Task.Run(() =>
                {
                    SalesManDeleted = SalesManDAL.DeleteSalesManDAL(deleteSalesManID);
                    Serialize();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return SalesManDeleted;
        }

        /// <summary>
        /// Updates SalesMan's password based on SalesManID.
        /// </summary>
        /// <param name="updateSalesMan">Represents SalesMan details including SalesManID, Password.</param>
        /// <returns>Determinates whether the existing SalesMan's password is updated.</returns>
        public async Task<bool> UpdateSalesManPasswordBL(SalesMan updateSalesMan)
        {
            bool passwordUpdated = false;
            try
            {
                if ((await Validate(updateSalesMan)) && (await GetSalesManBySalesManIDBL(updateSalesMan.SalesManID)) != null)
                {
                    this.SalesManDAL.UpdateSalesManPasswordDAL(updateSalesMan);
                    passwordUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return passwordUpdated;
        }

        /// <summary>
        /// Adds new Sales to SalesMan's SalesIDs collection.
        /// </summary>
        /// <param name="saleOrderID">Contains the order Id of the sale to be added.</param>
        /// <param name="salesManID">Contains the Id of the salesman who made the sale.</param>
        /// <returns>Determinates whether the new sale ID is added.</returns>
        public async Task<bool> AddSalesBL(Guid saleOrderID, Guid salesManID)
        {
            bool saleIDAdded = false;
            try
            {
                    await Task.Run(() =>
                    {
                        this.SalesManDAL.AddSalesDAL(saleOrderID,salesManID);
                        saleIDAdded = true;
                        Serialize();
                    });
            }
            catch (Exception)
            {
                throw;
            }
            return saleIDAdded;
        }

        /// <summary>
        /// Get the collection of SaleIDs of a salesman.
        /// </summary>
        /// <param name="salesManID">Contains the Id of the salesman who's saleIDs are required.</param>
        /// <returns>Collection of salesIDs of salesman.</returns>
        Task<List<Guid>> GetSalesBL(Guid salesManID)
        {
            List<Guid> saleIDs = null;

            SalesMan matchingSalesMan = null;
            try
            {
                await Task.Run(() =>
                {
                    matchingSalesMan = SalesManDAL.GetSalesManBySalesManIDDAL(searchSalesManID);
                    saleIDs = matchingSalesMan.SalesIDs;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return saleIDs
;

        }

        /// <summary>
        /// Search order in the sales of a salesman.
        /// </summary>
        /// <param name="searchSalesID">Contains the Id of the order to be searched.</param>
        /// <param name="salesManID">Contains the Id of the salesman who's orders are to be searched.</param>
        /// <returns>Collection of salesIDs of salesman.</returns>
        Task<Order> SearchSalesBL(Guid searchSalesID, Guid salesManID)
        {
            Order order = new Order();
            SalesMan matchingSalesman = GetSalesManBySalesManIDBL(salesmanID);
            try
            {
                await Task.Run(() =>
                {
                    if (this.SalesManDAL.SearchSalesDAL(searchSalesID, salesManID))
                        order = GetOrderByOrderID(searchSalesID);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return order;

        }

        /// <summary>
        /// Add sales order by salesman.
        /// </summary>
        /// <param name="newOrder">Contains the Order details such OrderID,Amount etc. of the order to be added.</param>
        /// <param name="salesManID">Contains the Id of the salesman who placed the order.</param>
        /// <returns>Determines whether order is added.</returns>
        Task<bool> AddSalesOrderBL(Order newOrder, Guid salesManID)
        {
            bool orderUploaded = false;
            try
            {
                if (await OrderBL.AddOrderBL(newOrder)) // Add to list of orders placed
                {
                    await Task.Run(() =>
                    {
                        if (AddSalesBL(newOrder.OrderID, salesManID))  // Add order Id to list of sales of salesman

                            orderUploaded = true;
                        Serialize();
                    });

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// View orderID of requests made for offline sale.
        /// </summary>
        Task<List<Order>> ViewActiveOrdersBL()
        {
            List<Order> activeOrders = new List<Order>();
            try
            {
                await Task.Run(() =>
                {
                    activeOrders = SearchOrderForOfflineBL();
                });
               
            }


            catch (Exception ex)
            {
                throw ex;
            }

            return activeOrders;
        }

        /// <summary>
        /// Add sales order by salesman.
        /// </summary>
        /// <param name="activeOrderID">Contains the OrderID of order to be accepted.</param>
        /// <returns>Determines whether order is accepted.</returns>
        Task<bool> AcceptOrderForSaleBL(Guid activeOrderID)
        {
            bool orderAccepted = false;
            Order matchingOrder = GetOrderByOrderIDBL(activeOrderID); // search for active order in the list of orders
            try
                {
                    await Task.Run(() =>
                    {
                        matchingOrder.Status = "Under Processing";       // change status of order
                        orderAccepted = OrderBL.UpdateOrderBL(matchingOrder);  // update status of order

                    });
                }
              
           

            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Modifies order details of the sales order.
        /// </summary>
        /// <param name="updatedOrder">Contains the OrderID of order to be accepted.</param>
        /// <returns>Determines whether order is modified.</returns>
        Task<bool> ModifySalesOrderBL(Order updatedOrder)
        {
            bool orderModified = false;
            Order matchingOrder = GetOrderByOrderID(updatedOrder.OrderID);  // Search for the required order
            try
            {
                await Task.Run(() =>
                {
                    if (UpdateOrderBL(updatedOrder))       // update order
                        orderModified = true;

                });
            }


            catch (Exception ex)
            {
                throw ex;
            }

            return orderModified;
        }

        /// <summary>
        /// Confirm sales order.
        /// </summary>
        /// <param name="confirmOrderID">Contains the OrderID of confirmed order.</param>
        /// <param name="salesManID">Contains the salesmanID of salesman who made the sale.</param>
        /// <returns>Determines whether order is modified.</returns>
        Task<bool> ConfirmSalesOrderBL(Guid confirmOrderID, Guid salesManID)
        {
            bool orderConfirmed = false;
            Order matchingOrder = GetOrderByOrderID(confirmOrderID);
            matchingOrder.Status = "Delivered";
            try
            {
                await Task.Run(() =>
                {
                    if (await UpdateOrderBL(matchingOrder))       // update order
                    {
                        if (await AddSalesBL(confirmOrderID, salesManID))
                            orderConfirmed = true;

                    }

                });              
            }

            catch (Exception ex)
            {
                throw ex;
            }

            return orderConfirmed;
        }


        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((SalesManDAL)SalesManDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                SalesManDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                SalesManDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}



