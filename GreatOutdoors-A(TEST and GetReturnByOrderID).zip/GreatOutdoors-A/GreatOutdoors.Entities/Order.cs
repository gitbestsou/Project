﻿using Capgemini.GreatOutdoors.Helpers.ValidationAttributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Entities
{
    //public enum Status
    //{
    //    InCart, UnderProcessing, Shipped, Delivered,Return,Cancel
    //}

    public enum Channel
    {
        Offline, Online
    }

    //Interface for Order class
    public interface IOrder
    {
        Guid OrderID { get; set; }
        int TotalQuantity { get; set; }
        double TotalAmount { get; set; }
        Guid AddressID { get; set; }
        //string ShippingAddress { get; set; }
        DateTime OrderDateTime { get; set; }
        Guid RetailerID { get; set; }
        Guid SalesPersonID { get; set; }
    }
    public class Order
    {
        [Required("Order ID can't be blank.")]
        public Guid OrderID { get; set; }

        public int TotalQuantity { get; set; }
        public double TotalAmount { get; set; }

        [Required("Address can't be blank.")]
        public Guid AddressID { get; set; }
        //public string ShippingAddress { get; set; }
        public DateTime OrderDateTime { get; set; }
        public Channel ChannelOfSale { get; set; }
        public Guid RetailerID { get; set; }
        //public Status CurrentStatus { get; set; }
        public Guid SalesPersonID { get; set; }

        //Constructor
        public Order()
        {
            OrderID = default(Guid);
            TotalQuantity = 0;
            TotalAmount = 0;
            AddressID = default(Guid);
            ChannelOfSale = 0;
            RetailerID = default(Guid);
            OrderDateTime = default(DateTime);
          //  CurrentStatus = 0;
            SalesPersonID = default(Guid);
        }

    }
}

