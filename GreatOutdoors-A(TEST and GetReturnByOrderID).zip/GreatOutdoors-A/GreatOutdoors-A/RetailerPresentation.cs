﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using GreatOutdoors.BusinessLayer;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class RetailerPresentation
    {
        /// <summary>
        /// Menu for Retailer
        /// </summary>
        /// <returns></returns>
        public static async Task<int> RetailerMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***************RETAILER***********");
                WriteLine("1. Initiate Order");
                WriteLine("2. View My Orders");
                WriteLine("3. Return Order");
                WriteLine("4. Cancel Order ");
                WriteLine("5.View My Returns");
                WriteLine("6. Manage Delievery Address");
                WriteLine("-----------------------");
                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("Choice: ");

                //Get current Retailer details
                IRetailerBL currRetailerBL = new RetailerBL();
                Retailer retailer = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);

                Guid currentRetailerID = retailer.RetailerID;


                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            //Call Method for placing order
                            await MakeOrder.ViewProducts();//Current Retailer ID

                            break;
                        case 2:
                            //Call Method for viewing retailer orders
                            using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                Console.WriteLine("#\tOrderID\tQuantity\tTotal Amount\tOrder Date");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");

                                    }
                                }

                                // Select order from list
                                Console.WriteLine("Please Select the Order  : ");
                                int orderSelection = int.Parse(Console.ReadLine());
                                using (IOrderDetailsBL accessOrderDetails = new OrderDetailsBL())
                                {
                                    List<OrderDetail> orderDetail = new List<OrderDetail>();
                                    orderDetail = await accessOrderDetails.GetOrderDetailsByOrderIDBL(orderHistory[orderSelection - 1].OrderID);

                                    // Printing products in the order
                                    Console.WriteLine("Products in this Order: ");
                                    if (orderDetail != null && orderDetail?.Count > 0)
                                    {
                                        Console.WriteLine(".......................");
                                        int serial = 0;
                                        foreach (var product in orderDetail)
                                        {
                                            serial++;
                                            ProductBL productBL = new ProductBL();
                                            string productName = (await productBL.GetProductByProductIDBL(product.ProductID)).ProductName;
                                            Console.WriteLine($"{serial}\t{productName}\t{product.Quantity}\t{product.UnitPrice}\t{product.Status}");
                                        }
                                    }
                                }

                            }
                            break;
                        case 3:
                            await PlaceReturn.ReturnRequest(currentRetailerID,CommonData.CurrentUserType);
                            
                            break;
                        case 4:
                            await CancelOrder.CancelRequest(currentRetailerID,CommonData.CurrentUserType);
                            //Call Method for Cancelling an order
                            //using (IOrdersBL orderAccess = new OrderBL())
                            //{

                            //    List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                            //    //Print order history
                            //    Console.WriteLine("ORDERS HISTORY: ");
                            //    if (orderHistory != null && orderHistory?.Count > 0)
                            //    {
                            //        Console.WriteLine(".......................");
                            //        int serial = 0;
                            //        foreach (Order order in orderHistory)
                            //        {
                            //            serial++;
                            //            Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                            //        }
                            //    }
                            //    WriteLine("Select Order to Return: ");
                            //    int SNo = int.Parse(ReadLine())-1;
                            //    if (orderHistory[SNo].CurrentStatus != Status.Shipped || orderHistory[SNo].CurrentStatus != Status.Delivered || orderHistory[SNo].CurrentStatus != Status.Return)
                            //    {
                            //        orderHistory[SNo].CurrentStatus = Status.Cancel;
                            //        Console.WriteLine("Cancellation Initiated.");
                            //    }
                            //    else
                            //    {
                            //        WriteLine("Cancellation Not Possible.");
                            //    }
                            //}

                            break;

                        case 5:
                            await PlaceReturn.ViewReturns(currentRetailerID,CommonData.CurrentUserType);
                            break;
                        case 6:
                            //Show Options
                            Console.WriteLine("Select Operation : ");
                            WriteLine("1. Add Addresses.");
                            WriteLine("2. View My Addresses");
                            WriteLine("3. Remove Addresses");
                            int opSelected = int.Parse(Console.ReadLine());
                            using (IAddressBL addresses = new AddressBL())
                            {
                                switch (opSelected)
                                {

                                    case 1:
                                        {
                                            Address newAddress = new Address();
                                            Console.WriteLine("Enter Line 1 : ");
                                            newAddress.Line1 = Console.ReadLine();
                                            Console.WriteLine("Enter Line 2 : ");
                                            newAddress.Line2 = Console.ReadLine();
                                            Console.WriteLine("Enter City : ");
                                            newAddress.City = Console.ReadLine();
                                            Console.WriteLine("Enter State : ");
                                            newAddress.State = Console.ReadLine();
                                            Console.WriteLine("Enter Pincode(Six Digit) : ");
                                            newAddress.Pincode = int.Parse(Console.ReadLine());
                                            Console.WriteLine("Enter Mobile No. : ");
                                            newAddress.MobileNo = Console.ReadLine();
                                            newAddress.RetailerID = currentRetailerID;
                                            bool added = await addresses.AddAddressBL(newAddress);
                                        }
                                        break;
                                    case 2:
                                        {
                                            List<Address> storedAddresses =  await addresses.GetAddressByRetailerIDBL(currentRetailerID);
                                            int addserial = 0;
                                            foreach (var item in storedAddresses)
                                            {
                                                addserial++;
                                                Console.WriteLine($"{addserial}\t{item.Line1}\t{item.Line2}\t{item.City}\t{item.State}\t{item.Pincode}");
                                            }
                                        }
                                        break;
                                    case 3:
                                        {
                                            List<Address> storedAddresses =  await addresses.GetAddressByRetailerIDBL(currentRetailerID);
                                            int addserial = 0;
                                            foreach (var item in storedAddresses)
                                            {
                                                addserial++;
                                                Console.WriteLine($"{addserial}\t{item.Line1}\t{item.Line2}\t{item.City}\t{item.State}\t{item.Pincode}");
                                            }
                                            Console.WriteLine(" Select Address to delete : ");
                                            int chosenAddress = int.Parse(Console.ReadLine());
                                            bool removed = await addresses.DeleteAddressBL(storedAddresses[chosenAddress - 1].AddressID);

                                        }
                                        break;

                                }
                            }
                            break;

                        case 0: break;
                        case -1: break;
                        default:
                            WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }






    }
}



