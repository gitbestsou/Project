﻿using Capgemini.GreatOutdoors.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.Contracts.BLContracts
{
    public interface IReturnDetailsBL : IDisposable
    {
        Task<bool> AddReturnDetailsBL(ReturnDetails newReturnDetails);

        Task<List<ReturnDetails>> GetReturnDetailsByReturnIDBL(Guid searchReturnID);
        Task<List<ReturnDetails>> GetReturnDetailsByProductIDBL(Guid searchProductID);


        Task<bool> DeleteReturnDetailsBL(Guid deleteReturnID, Guid deleteProductID);

        //Task<double> CalculateDiscountPriceBL(Guid productID);

        double CalculateTotalReturnPriceBL(ReturnDetails returnDetails);

        Task<int> TotalQuantity(List<ReturnDetails> returnDetails);

        

    }
}
