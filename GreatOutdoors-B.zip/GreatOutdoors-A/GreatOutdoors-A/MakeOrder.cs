﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    class MakeOrder
    {
        public static async Task ViewProducts()
        {
            try
            {
                using (IProductBL productBL = new ProductBL())
                {
                    //Get and display list of products
                    List<Product> products = await productBL.GetAllProductsBL();
                    Console.WriteLine("PRODUCTS : ");
                    if (products != null && products?.Count > 0)
                    {
                        Console.WriteLine(".......................");
                        int serial = 0;
                        foreach (var product in products)
                        {
                            serial++;
                            Console.WriteLine($"{serial}\t{product.ProductID}\t{product.ProductName}\t{product.ProductSize}\t{product.ProductColour}\t{product.ProductTechSpecs}\t{product.SellingPrice}\t{product.ProductDiscount}");
                        }
                    }
                    using (IOrdersBL orderBL = new OrderBL())
                    {
                        Order order = new Order();
                        (bool orderConfirmed, Guid Id) = await orderBL.AddOrderBL(order);
                        order.OrderID = Guid.NewGuid();

                        using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
                        {
                            bool reply = true;
                            int serial = 0;
                            while (reply)
                            {
                                OrderDetail currentProduct = new OrderDetail();
                                currentProduct.OrderDetailID = Guid.NewGuid();
                                currentProduct.OrderID = order.OrderID;
                                Console.WriteLine("Select the product : ");
                                currentProduct.ProductID = products[int.Parse(Console.ReadLine()) - 1].ProductID;
                                Console.WriteLine("Enter Quantity : ");
                                currentProduct.Quantity = int.Parse(Console.ReadLine());
                                currentProduct.UnitPrice = await orderDetailsBL.CalculateDiscountPriceBL(currentProduct.ProductID);
                                currentProduct.TotalPrice = orderDetailsBL.CalculateTotalPriceBL(currentProduct);
                                bool isOrderAdded = await orderDetailsBL.AddOrderDetailsBL(currentProduct); // ask shreyash about error handling
                                serial++;
                                Console.WriteLine("You want to add another Product(Y/N) : ");
                                string replyConsole = Console.ReadLine();
                                if ((replyConsole.ToLower()).Equals("y"))
                                    reply = true;
                                else
                                    reply = false;
                            }
                            Console.WriteLine("You want to make payment(Y/N) ?");
                            string makePayment = (Console.ReadLine()).ToLower();
                            if (makePayment == "y")
                            {
                                List<OrderDetail> confirm = await orderDetailsBL.GetOrderDetailsByOrderIDBL(order.OrderID);

                                order.TotalQuantity = await orderDetailsBL.TotalQuantity(confirm);

                                order.TotalAmount = await orderDetailsBL.AmountPayable(confirm);

                                order.OrderDateTime = DateTime.Now;

                                order.ChannelOfSale = Channel.Online;

                                order.CurrentStatus = Status.UnderProcessing;

                                
                                Console.WriteLine("Thank you for shopping with us.");


                            }
                            if (makePayment == "n")
                            {
                                List<OrderDetail> delete = await orderDetailsBL.GetOrderDetailsByOrderIDBL(order.OrderID);
                                int count = delete.Count();
                                while (serial > 0)
                                {
                                    count--;
                                    await orderDetailsBL.DeleteOrderDetailsBL(delete[count].OrderID, delete[count].ProductID);
                                    serial--;
                                    Console.WriteLine("Thank you for shopping with us.");
                                }

                                //show him the retailer menu
                            }
                        }
                    }
                }
            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                Console.WriteLine(ex.Message);
            }
        }

        public static async Task CreateOrder()
        {

            using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
            {
                bool reply = true;
                while (reply)
                {
                    Console.WriteLine("Select the product :");
                    int Selection = int.Parse(Console.ReadLine());

                }

            }
        }
    }
}

