﻿using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.DataAccessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class PlaceReturn
    {
        public static async Task ReturnRequest(Guid currRetailerID)
        {
            try
            {
                using (IOrdersBL orderAccess = new OrderBL())
                {
                    List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currRetailerID);
                    Console.WriteLine("--Choose an Order to Initate a Return Request--");
                    if (orderHistory != null && orderHistory?.Count > 0)
                    {
                        Console.WriteLine(".......................");
                        int serial = 0;
                        foreach (Order order in orderHistory)
                        {
                            serial++;
                            Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                        }
                    }



                }



            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                Console.WriteLine(ex.Message);
            }
        }

    }
                            

                                
}
