﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Contracts.BLContracts;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class RetailerPresentation
    {
        /// <summary>
        /// Menu for SystemUser
        /// </summary>
        /// <returns></returns>
        public static async Task<int> RetailerMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***************SYSTEM USER***********");
                WriteLine("1. Initiate Order");
                WriteLine("2.View My Orders");
                WriteLine("3. Return Order");
                WriteLine("4. Cancel Order ");
                WriteLine("5.Change Password");
                WriteLine("-----------------------");
                WriteLine("0. Logout");
                WriteLine("-1. Exit");
                Write("Choice: ");


                IRetailerBL currRetailerBL = new RetailerBL();
                Retailer retailer = await currRetailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, CommonData.CurrentUser.Password);
                Guid currentRetailerID = retailer.RetailerID;


                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            //Call Method for placing order(await)
                            await MakeOrder.ViewProducts();//Current Retailer ID

                            break;
                        case 2:
                            //Call Method for viewing my orders
                            using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                                    }
                                }

                                // Select order from list
                                Console.WriteLine("Please Select the Order  : ");
                                int orderSelection = int.Parse(Console.ReadLine());
                                using (IOrderDetailsBL accessOrderDetails = new OrderDetailsBL())
                                {
                                    List<OrderDetail> orderDetail = new List<OrderDetail>();
                                    orderDetail = await accessOrderDetails.GetOrderDetailsByOrderIDBL(orderHistory[orderSelection - 1].OrderID);
                                    Console.WriteLine("Products in this Order: ");
                                    if (orderDetail != null && orderDetail?.Count > 0)
                                    {
                                        Console.WriteLine(".......................");
                                        int serial = 0;
                                        foreach (var product in orderDetail)
                                        {
                                            serial++;
                                            ProductBL productBL = new ProductBL();
                                            string productName = (await productBL.GetProductByProductIDBL(product.ProductID)).ProductName;
                                            Console.WriteLine($"{serial}\t{product.ProductID}\t{productName}\t{product.Quantity}\t{product.UnitPrice}");
                                        }
                                    }
                                }

                            }
                            break;
                        case 3:

                            await PlaceReturn.ReturnRequest(currentRetailerID);

                            /*using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                                    }
                                }
                                int SNo = int.Parse(ReadLine());
                                orderHistory[SNo].CurrentStatus = Status.Return;
                                Console.WriteLine("Return Generated");
                            }*/
                            break;
                        case 4:
                            //Call Method for Cancelling an order(await)
                            using (IOrdersBL orderAccess = new OrderBL())
                            {

                                List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currentRetailerID);
                                //Print order history
                                Console.WriteLine("ORDERS HISTORY: ");
                                if (orderHistory != null && orderHistory?.Count > 0)
                                {
                                    Console.WriteLine(".......................");
                                    int serial = 0;
                                    foreach (Order order in orderHistory)
                                    {
                                        serial++;
                                        Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                                    }
                                }
                                int SNo = int.Parse(ReadLine());
                                if (orderHistory[SNo].CurrentStatus != Status.Shipped || orderHistory[SNo].CurrentStatus != Status.Delivered)
                                {
                                    orderHistory[SNo].CurrentStatus = Status.Cancel;
                                    Console.WriteLine("Cancellation Initiated.");
                                }
                                else
                                {
                                    WriteLine("Cancellation Not Possible.");
                                }
                            }

                            break;
                        case 5:
                            await ChangeRetailerPassword();
                            break;

                        case 0: break;
                        case -1: break;
                        default:
                            WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }





        /// <summary>
        /// Updates Retailer's Password.
        /// </summary>
        /// <returns></returns>
        public static async Task ChangeRetailerPassword()
        {
            try
            {
                using (IRetailerBL retailerBL = new RetailerBL())
                {
                    //Read Current Password
                    Write("Current Password: ");
                    string currentPassword = ReadLine();

                    Retailer existingRetailer = await retailerBL.GetRetailerByEmailAndPasswordBL(CommonData.CurrentUser.Email, currentPassword);

                    if (existingRetailer != null)
                    {
                        //Read inputs
                        Write("New Password: ");
                        string newPassword = ReadLine();
                        Write("Confirm Password: ");
                        string confirmPassword = ReadLine();

                        if (newPassword.Equals(confirmPassword))
                        {
                            existingRetailer.Password = newPassword;

                            //Invoke UpdateSystemUserBL method to update
                            bool isUpdated = await retailerBL.UpdateRetailerPasswordBL(existingRetailer);
                            if (isUpdated)
                            {
                                WriteLine("Retailer Password Updated");
                            }
                        }
                        else
                        {
                            WriteLine($"New Password and Confirm Password doesn't match");
                        }
                    }
                    else
                    {
                        WriteLine($"Current Password doesn't match.");
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }
}



