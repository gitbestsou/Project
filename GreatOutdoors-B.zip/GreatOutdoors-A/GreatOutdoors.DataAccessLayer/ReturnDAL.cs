﻿using System;
using System.Collections.Generic;
using Capgemini.GreatOutdoors.Contracts.DALContracts;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using Capgemini.GreatOutdoors.Helpers;

namespace Capgemini.GreatOutdoors.DAL
{
    public class ReturnDAL : ReturnDALBase, IDisposable
    {
        public override bool AddReturnDAL(Return newReturn)
        {
            bool returnAdded = false;
            try
            {
                newReturn.ReturnID = Guid.NewGuid();
                //newDistributor.CreationDateTime = DateTime.Now;
                //newDistributor.LastModifiedDateTime = DateTime.Now;
                returnList.Add(newReturn);
                returnAdded = true;
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return returnAdded;
        }

        public override List<Return> GetAllReturnsDAL()
        {
            return returnList;
        }

        public override Return GetReturnByReturnIDDAL(Guid searchReturnID)
        {
            Return matchingReturn = null;
            try
            {
                //Find Distributor based on searchDistributorID
                matchingReturn = returnList.Find(
                    (item) => { return item.ReturnID == searchReturnID; }
                );
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return matchingReturn;
        }
        public override Return GetReturnByOrderIDDAL(Guid OrderID)
        {
            Return matchingReturn = null;
            /*Sourav will have to write this code*/
            return matchingReturn;
        }
        public override List<Return> GetReturnByRetailerIDDAL(Guid OrderID)
        {
            /*Sourav will have to write this code*/




            return returnList;
        }
        public override bool UpdateReturnDAL(Return updateReturn)
        {
            bool returnUpdated = false;
            try
            {
                //Find Distributor based on DistributorID
                Return matchingReturn = GetReturnByReturnIDDAL(updateReturn.ReturnID);

                if (matchingReturn != null)
                {
                    //Update distributor details
                    ReflectionHelpers.CopyProperties(updateReturn, matchingReturn, new List<string>() { "ReturnIncomplete", "ReturnWrong", "ReturnValue", "ReturnQuantity" });
                    matchingReturn.ReturnDateTime = DateTime.Now;

                    returnUpdated = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return returnUpdated;
        }

        public override bool DeleteReturnDAL(Guid deleteReturnID)
        {
            bool returnDeleted = false;
            try
            {
                //Find Distributor based on searchDistributorID
                Return matchingReturn = returnList.Find(
                    (item) => { return item.ReturnID == deleteReturnID; }
                );

                if (matchingReturn != null)
                {
                    //Delete Distributor from the collection
                    returnList.Remove(matchingReturn);
                    returnDeleted = true;
                }
            }
            catch (GreatOutdoorsException)
            {
                throw;
            }
            return returnDeleted;
        }

        public void Dispose()
        {

        }





    }
}
