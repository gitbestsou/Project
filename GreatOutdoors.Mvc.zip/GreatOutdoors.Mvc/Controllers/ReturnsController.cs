﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using GreatOutdoors.Mvc.Models;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using System.Threading.Tasks;

namespace GreatOutdoors.Mvc.Controllers
{
    public class ReturnsController : Controller
    {
        //Creating and initializing viewmodel object
        // GET: Returns
        //URL:Returns/Create
        public async Task<ActionResult> Create()
        {
            Order order = new Order();
            List<Order> orders = new List<Order>();
            using (IOrdersBL ordersBL = new OrderBL())
            {
                orders = await ordersBL.GetAllOrdersBL();
            }
            ViewBag.orderlist = new SelectList(orders, "OrderID", "OrderDateTime");
            ReturnViewModel returnViewModel = new ReturnViewModel()
                {
                    //ReasonOfReturn = "Wrong"
                };
            return View(returnViewModel);
        }
    }
}