﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Web.Mvc;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;


/*Salesperson Controller which contains methods to perform Create, Edit, Delete and Display Sales persons
Project name : Great Outdoors
Developer name: Madhuri Vemulapaty
Use case : Salesperson
Creation date : 25/10/2019
Last modified : 29/10/2019
 */

namespace GreatOutdoors.MVC.Controllers
{
    public class SalesPersonsController : Controller
    {
        /// <summary>
        /// Method to display and take the values of Add New Sales Person form
        /// </summary>
        /// <returns> Returns view of add product form</returns>
        public ActionResult Create()
        {
            //Create an object of Salesperson ViewModel
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            //Calling View and passing object to View
            return View(salesPersonViewModel);
        }

        /// <summary>
        /// Method to Add new salesperson to database
        /// </summary>
        /// <param name="salesPersonViewModel"></param>
        /// <returns>returns view of index of salespersons if salesperson is added successfully or displays error message</returns>
        [HttpPost]
        public async Task<ActionResult> Create(SalesPersonViewModel salesPersonViewModel)
        {
            bool isAdded = false;
            SalesPerson salesPerson = new SalesPerson();
            //Copying the values of the form to salesperson entity
            salesPerson.Name = salesPersonViewModel.Name;
            salesPerson.Mobile = salesPersonViewModel.Mobile;
            salesPerson.Email = salesPersonViewModel.Email;
            salesPerson.Password = salesPersonViewModel.Password;
            salesPerson.JoiningDate = salesPersonViewModel.JoiningDate;
            salesPerson.Salary = salesPersonViewModel.Salary;
            salesPerson.Bonus = salesPersonViewModel.Bonus;
            salesPerson.Target = salesPersonViewModel.Target;
            salesPerson.Birthdate = salesPersonViewModel.Birthdate;
            salesPerson.AddressLine1 = salesPersonViewModel.AddressLine1;
            salesPerson.AddressLine2 = salesPersonViewModel.AddressLine2;
            salesPerson.City = salesPersonViewModel.City;
            salesPerson.State = salesPersonViewModel.State;
            salesPerson.Pincode = salesPersonViewModel.Pincode;


            SalesPersonBL salesPersonBL = new SalesPersonBL();
            //Adding the new salesperson to the Database
            isAdded = await salesPersonBL.AddSalesPersonBL(salesPerson);

            if (isAdded)
                //Redirecting to Index of Salespersons if addition is successful
                return RedirectToAction("Index", "SalesPersons");
            else
                //Displaying error message if addition is unsuccessful
                return Content("Sales person couldn't be added");

        }

        // URL:SalesPersons/Edit
        /// <summary>
        /// Method to display the edit form of selected salesperson
        /// </summary>
        /// <param name="id">Id of the selected salesperson</param>
        /// <returns>Returns the view of edit form</returns>
        public async Task<ActionResult> Edit(Guid id)
        {
            //Creating ViewModel object
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            //Retrieving the selected salesperson and itś details by ID
            SalesPerson salesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(id);
            //Displaying existing details
            salesPersonViewModel.SalespersonID = id;
            salesPersonViewModel.Salary = salesPerson.Salary;
            salesPersonViewModel.Bonus = salesPerson.Bonus;
            salesPersonViewModel.Target = salesPerson.Target;



            //Calling View and passing ViewModel object to view
            return View(salesPersonViewModel);
        }

        /// <summary>
        /// Method to post the edit form data and store the updated details in the database
        /// </summary>
        /// <param name="salesPersonViewModel"></param>
        /// <returns>Returns index view of products if edit is successful or displays error message</returns>
        [HttpPost]
        public async Task<ActionResult> Edit(SalesPersonViewModel salesPersonViewModel)
        {

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson salesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(salesPersonViewModel.SalespersonID);
            //Updating the product details from the edit form
            salesPerson.Salary = salesPersonViewModel.Salary;
            salesPerson.Bonus = salesPersonViewModel.Bonus;
            salesPerson.Target = salesPersonViewModel.Target;

            //Calling method to update details in the database
            bool isUpdated = await salesPersonBL.UpdateSalesPersonDetailsBL(salesPerson);

            if (isUpdated)
                //Redirecting to Index of Sales persons if updation is successful
                return RedirectToAction("Index");
            else
                //Displaying error message if updation is unsuccessful
                return Content("Sales person couldn't be updated");
        }

        // URL:SalesPersons/Index
        /// <summary>
        /// Method to display the list of sales persons in the database
        /// </summary>
        /// <returns>Returns the view of sales persons in the database</returns>
        // URL:Products/Index
        public async Task<ActionResult> Index()
        {
            //Creating ViewModel object
            List<SalesPersonViewModel> salesPersonViewModels = new List<SalesPersonViewModel>();

            List<SalesPerson> salesPersons = new List<SalesPerson>();
            SalesPersonBL salesPersonBL = new SalesPersonBL();

            //Getting all the sales persons from the database
            salesPersons = await salesPersonBL.GetAllSalesPersonsBL();

            foreach (var salesPerson in salesPersons)
            {
                //Copying details of each sales person to salesPersonViewModel
                SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel()
                {
                    SalespersonID = salesPerson.SalespersonID,
                    Name = salesPerson.Name,
                    Email = salesPerson.Email,
                    Mobile = salesPerson.Mobile,
                    Password = salesPerson.Password,
                    JoiningDate = salesPerson.JoiningDate,
                    Birthdate = salesPerson.Birthdate,
                    Salary = salesPerson.Salary,
                    Bonus = salesPerson.Bonus,
                    Target = salesPerson.Target,
                    AddressLine1 = salesPerson.AddressLine1,
                    AddressLine2 = salesPerson.AddressLine2,
                    City = salesPerson.City,
                    State = salesPerson.State,
                    Pincode = salesPerson.Pincode,
                    LastAccountModifiedDateTime = salesPerson.LastAccountModifiedDateTime,


                };

                //Adding the salesPersonViewModel to the list
                salesPersonViewModels.Add(salesPersonViewModel);
            }


            //Calling View and passing ViewModel object to view
            return View(salesPersonViewModels);
        }

        /// <summary>
        /// Method to delete the selected sales person from database
        /// </summary>
        /// <param name="id">Id of the selected sales person</param>
        /// <returns>Returns index view of sales persons if deletion is successful or displays error message</returns>
        public async Task<ActionResult> Delete(Guid id)
        {
            SalesPersonBL salesPersonBL = new SalesPersonBL();
            //Deleting the sales person from the database using the given ID
            bool isDeleted = await salesPersonBL.DeleteSalesPersonBL(id);

            if (isDeleted)
                //Redirecting to Index of Sales persons if deletion is successful
                return RedirectToAction("Index");
            else
                //Displaying error message if deletion is unsuccessful
                return Content("Sales person couldn't be deleted");
        }

    }
}