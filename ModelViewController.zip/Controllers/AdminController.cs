﻿using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Threading.Tasks;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        public async Task<ActionResult> Home()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            AdminViewModel adminViewModel = new AdminViewModel();

            admin.AdminID = Guid.Parse(Convert.ToString(Session["AdminID"]));

            admin = await adminBL.GetAdminByAdminIDBL(admin.AdminID);
            adminViewModel.AdminID = admin.AdminID;
            adminViewModel.AdminName = admin.AdminName;
            adminViewModel.Email = admin.Email;

            return View(adminViewModel);
        }

        public async Task<ActionResult> Edit()
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            AdminViewModel adminViewModel = new AdminViewModel();
            admin.AdminID = (Guid)Session["AdminID"];
            admin = await adminBL.GetAdminByAdminIDBL(admin.AdminID);
            adminViewModel.AdminID = admin.AdminID;
            adminViewModel.AdminName = admin.AdminName;
            adminViewModel.Email = admin.Email;

            return View(adminViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Edit(AdminViewModel adminViewModel)
        {
            Admin admin = new Admin();
            AdminBL adminBL = new AdminBL();
            admin = await adminBL.GetAdminByAdminIDBL(adminViewModel.AdminID);

            admin.AdminName = adminViewModel.AdminName;
            admin.Email = adminViewModel.Email;

            bool isupdate = await adminBL.UpdateAdminBL(admin);

            if (isupdate)
            {
                return RedirectToAction("Home");
            }
            else
                return Content("Admin can't be updated");
        }

        /// <summary>
        /// Method to display change password form of Admin
        /// </summary>
        /// <param name="id">Current Admin ID</param>
        /// <returns>Returns the view of change password of Admin</returns>
        public async Task<ActionResult> ChangePassword(Guid id)
        {
            AdminViewModel adminViewModel = new AdminViewModel();

            AdminBL adminBL = new AdminBL();
            //Retrieving the current admin who is logged
            Admin currentAdmin = await adminBL.GetAdminByAdminIDBL(id);

            // Copying the required values
            adminViewModel.AdminName = currentAdmin.AdminName;
            adminViewModel.Email = currentAdmin.Email;
            adminViewModel.AdminID = id;



            return View(adminViewModel);
        }

        /// <summary>
        /// Method to update the password of Admin
        /// </summary>
        /// <param name="adminViewModel">ViewModel of change password of admin</param>
        /// <returns>Redirects to admin home page or displays an error message if updation is not successful</returns>
        [HttpPost]
        public async Task<ActionResult> ChangePassword(AdminViewModel adminViewModel)
        {

            AdminBL adminBL = new AdminBL();
            Admin currentAdmin = await adminBL.GetAdminByAdminIDBL(adminViewModel.AdminID);

            //Checking if current password entered is same as the one in records
            if (!adminViewModel.Password.Equals(currentAdmin.Password))
            {
                ViewBag.Message = "You have entered an incorrect password";
                return View(adminViewModel);
            }
            //Checking if new password is same as confirm password
            else if (!adminViewModel.NewPassword.Equals(adminViewModel.ConfirmNewPassword))
            {
                ViewBag.Message = "The new password does not match with the confirm password";
                return View(adminViewModel);
            }
            //Updating the details once the conditions are satisfied
            else
            {
                currentAdmin.Password = adminViewModel.NewPassword;
            }


            //Updating the password in the database
            bool isUpdated = await adminBL.UpdateAdminPasswordBL(currentAdmin);

            if (isUpdated)
                //Redirecting to home when updation is successful
                return RedirectToAction("Home");
            else
                //Displaying error message when updation is unsuccessful
                return Content("Your password could not be updated.");
        }
    }
}