﻿using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

/*Salesperson Controller which contains methods to perform Display details and edit profile
Project name : Great Outdoors
Developer name: Madhuri Vemulapaty
Use case : Salesperson
Creation date : 25/10/2019
Last modified : 29/10/2019
 */
namespace GreatOutdoors.MVC.Controllers
{
    public class SalesPersonController : Controller
    {
        // GET: SalesPerson
        /// <summary>
        /// Method to display the sales person's profile
        /// </summary>
        /// <returns>Returns view of sales person's home page</returns>
        public async Task<ActionResult> Home()
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();
            //Getting the id of the sales person who is currently logged in
            Guid currentSalesPersonID = (Guid)Session["SalesPersonID"];
            SalesPersonBL salesPersonBL = new SalesPersonBL();

            //Retrieving the sales person by the id
            SalesPerson salesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(currentSalesPersonID);

            //Copying data to ViewModel
            salesPersonViewModel.SalespersonID = salesPerson.SalespersonID;
            salesPersonViewModel.Name = salesPerson.Name;
            salesPersonViewModel.Mobile = salesPerson.Mobile;
            salesPersonViewModel.Email = salesPerson.Email;
            salesPersonViewModel.JoiningDate = salesPerson.JoiningDate;
            salesPersonViewModel.Salary = salesPerson.Salary;
            salesPersonViewModel.Bonus = salesPerson.Bonus;
            salesPersonViewModel.Target = salesPerson.Target;

            return View(salesPersonViewModel);
        }

        /// <summary>
        /// Method to display the Edit form of sales person - Mobile,Email and Name
        /// </summary>
        /// <param name="id">ID of sales person</param>
        /// <returns>Returns edit page view</returns>
        public async Task<ActionResult> Edit(Guid id)
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            //Retrieving the data of current sales person who is logged in
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(id);

            //Copying the required values
            salesPersonViewModel.Name = currentSalesPerson.Name;
            salesPersonViewModel.Mobile = currentSalesPerson.Mobile;
            salesPersonViewModel.Email = currentSalesPerson.Email;
            salesPersonViewModel.SalespersonID = id;

            return View(salesPersonViewModel);
        }

        /// <summary>
        /// Method to update the changed details of sales person
        /// </summary>
        /// <param name="salesPersonViewModel">The view displayed in the edit form</param>
        /// <returns>Redirects to the home page if successfully updated or displays error message in case of an error</returns>
        [HttpPost]
        public async Task<ActionResult> Edit(SalesPersonViewModel salesPersonViewModel)
        {

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(salesPersonViewModel.SalespersonID);

            //Updating the sales person's details
            currentSalesPerson.Name = salesPersonViewModel.Name;
            currentSalesPerson.Email = salesPersonViewModel.Email;
            currentSalesPerson.Mobile = salesPersonViewModel.Mobile;

            // Updating the details in the database
            bool isUpdated = await salesPersonBL.UpdateSalesPersonBL(currentSalesPerson);

            if (isUpdated)
                //Redirecting to Home page of sales person if updation is successful
                return RedirectToAction("Home");
            else
                //Displaying error message if the updation is unsuccessful
                return Content("Your profile could not be updated.");
        }

        /// <summary>
        /// Method to display change password form of sales person
        /// </summary>
        /// <param name="id">Current sales person ID</param>
        /// <returns>Returns the view of change password of sales person</returns>
        public async Task<ActionResult> ChangePassword(Guid id)
        {
            SalesPersonViewModel salesPersonViewModel = new SalesPersonViewModel();

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            //Retrieving the current sales person who is logged
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(id);

            // Copying the required values
            salesPersonViewModel.Name = currentSalesPerson.Name;
            salesPersonViewModel.Email = currentSalesPerson.Email;
            salesPersonViewModel.SalespersonID = id;



            return View(salesPersonViewModel);
        }

        /// <summary>
        /// Method to update the password of sales person
        /// </summary>
        /// <param name="salesPersonViewModel">ViewModel of change password of sales person</param>
        /// <returns>Redirects to sales person home page or displays an error message if updation is not successful</returns>
        [HttpPost]
        public async Task<ActionResult> ChangePassword(SalesPersonViewModel salesPersonViewModel)
        {

            SalesPersonBL salesPersonBL = new SalesPersonBL();
            SalesPerson currentSalesPerson = await salesPersonBL.GetSalesPersonBySalesPersonIDBL(salesPersonViewModel.SalespersonID);

            //Checking if current password entered is same as the one in records
            if (!salesPersonViewModel.Password.Equals(currentSalesPerson.Password))
            {
                ViewBag.Message = "You have entered an incorrect password";
                return View(salesPersonViewModel);
            }
            //Checking if new password is same as confirm password
            else if (!salesPersonViewModel.NewPassword.Equals(salesPersonViewModel.ConfirmNewPassword))
            {
                ViewBag.Message = "The new password does not match with the confirm password";
                return View(salesPersonViewModel);
            }
            //Updating the details once the conditions are satisfied
            else
            {
                currentSalesPerson.Password = salesPersonViewModel.NewPassword;
            }


            //Updating the password in the database
            bool isUpdated = await salesPersonBL.UpdateSalesPersonPasswordBL(currentSalesPerson);

            if (isUpdated)
                //Redirecting to home when updation is successful
                return RedirectToAction("Home");
            else
                //Displaying error message when updation is unsuccessful
                return Content("Your password could not be updated.");
        }

    }
}