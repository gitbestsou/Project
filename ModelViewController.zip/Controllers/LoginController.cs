﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Capgemini.GreatOutdoors.BusinessLayer;
using GreatOutdoors.Entities;
using GreatOutdoors.MVC.Models;

namespace GreatOutdoors.MVC.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Login()
        {
           
            LoginViewModel loginViewModel = new LoginViewModel();
            Session["User"] = "None";

            return View(loginViewModel);
        }

        [HttpPost]
        public async Task<ActionResult> Login(LoginViewModel loginViewModel)
        {
            LoginViewModel loginViewModel1 = new LoginViewModel();
            if (loginViewModel.UserType == "Admin")
            {
                Admin admin = new Admin();
                AdminBL adminBL = new AdminBL();
                admin.Email = loginViewModel.Email;
                admin.Password = loginViewModel.Password;
                admin = await adminBL.GetAdminByEmailAndPasswordBL(admin.Email, admin.Password);
                if (admin != null)
                {
                    Session["AdminID"] = admin.AdminID;
                    Session["User"] = "Admin";
                    return RedirectToAction("Home","Admin");
                }
                else
                {
                    ViewBag.Message = String.Format("Invalid Credentials!!");
                    return View(loginViewModel);
                }
            }

            if (loginViewModel.UserType == "Sales Person")
            {
                SalesPerson salesPerson = new SalesPerson();
                SalesPersonBL salesPersonBL = new SalesPersonBL();
                salesPerson = await salesPersonBL.GetSalesPersonByEmailAndPasswordBL(loginViewModel.Email, loginViewModel.Password);
                if (salesPerson != null)
                {
                    Session["SalesPersonID"] = salesPerson.SalespersonID;
                    Session["User"] = "Sales Person";
                    return RedirectToAction("Home","SalesPerson");
                }
                else
                {
                    ViewBag.Message = String.Format("Invalid Credentials!!");
                    return View(loginViewModel);
                }

            }

            if (loginViewModel.UserType == "Retailer")
            {
                Retailer retailer = new Retailer();
                RetailerBL retailerBL = new RetailerBL();
                retailer = await retailerBL.GetRetailerByEmailAndPasswordBL(loginViewModel.Email, loginViewModel.Password);
                if (retailer != null)
                {
                    Session["RetailerID"] = retailer.RetailerID;
                    Session["User"] = "Retailer";
                    return RedirectToAction("Profile","Retailers");
                }
                else
                {
                    ViewBag.Message = String.Format("Invalid Credentials!!");
                    return View(loginViewModel);
                }

            }

            else
                Content("Invalid User Type!!");

            return View();

        }
    }
}