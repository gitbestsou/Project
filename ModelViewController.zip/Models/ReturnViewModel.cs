﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace GreatOutdoors.Mvc.Models
{
    /*Return ViewModel
    Project name : Great Outdoors
    Developer name: Sourav Maji
    Use case : Return
    Creation date : 30/10/2019
    Last modified : 08/11/2019
    */
    public class ReturnViewModel
    {
        //Creating the necessary properties for ReturnHistory view
        
        public System.Guid ReturnID { get; set; }
        public System.Guid ReturnDetailID { get; set; }
        public System.Guid ProductID { get; set; }
        public string ProductName { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public DateTime ReturnDateTime { get; set; }        
        public string ReasonOfReturn { get; set; }
        public decimal TotalAmount { get; set; }       
    }
}