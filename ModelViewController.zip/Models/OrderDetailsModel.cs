﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace GreatOutdoors.Mvc.Models
{
    public class OrderDetailsModel
    {
        public System.Guid OrderDetailID { get; set; }

        public System.Guid OrderID { get; set; }
        public System.Guid ProductID { get; set; }

        [Required(ErrorMessage = "Please Enter a Quantity.")]
        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter only numbers.")]
        public int Quantity { get; set; }

        public decimal DiscountedUnitPrice { get; set; }
        public decimal TotalPrice { get; set; }
        public Nullable<bool> GiftPacking { get; set; }
        public System.Guid AddressID { get; set; }
        public string CurrentStatus { get; set; }
        public string Address { get; set; }




        //Order
        public System.Guid RetailerID { get; set; }
        public int TotalQuantity { get; set; }
        public decimal TotalAmount { get; set; }
        public string ChannelOfSale { get; set; }



        public string Name { get; set; }
        public string Category { get; set; }
        public Nullable<int> Stock { get; set; }
        public string Size { get; set; }
        public string Colour { get; set; }
        public string TechnicalSpecifications { get; set; }
        public Nullable<decimal> CostPrice { get; set; }
        public Nullable<decimal> SellingPrice { get; set; }
        public Nullable<decimal> DiscountPercentage { get; set; }

    }
}




