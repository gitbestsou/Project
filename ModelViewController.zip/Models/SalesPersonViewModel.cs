﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations;

/*Salesperson ViewModel which contains properties like - Name, mobile, email, address etc. of a sales person
Project name : Great Outdoors
Developer name: Madhuri Vemulapaty
Use case : Salesperson
Creation date : 25/10/2019
Last modified : 29/10/2019
 */
namespace GreatOutdoors.MVC.Models
{
    public class SalesPersonViewModel
    {
        public Guid SalespersonID { get; set; }

        [Required(ErrorMessage = "Name can't be blank")]
        [MinLength(2, ErrorMessage = "Name should contain atleast 2 characters")]
        [MaxLength(40, ErrorMessage = "Name can contain atmost 40 characters")]
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "Name should contain only alphabets")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Mobile number can't be blank")]
        [RegularExpression("^([9]{1})([234789]{1})([0-9]{8})$", ErrorMessage = "Please enter valid mobile number")]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Email can't be blank")]
        [RegularExpression(@"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$",
            ErrorMessage = "Please enter valid email address")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Password can't be blank")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})", ErrorMessage = "Password should be 6 to 15 characters with at least one digit, one uppercase letter, one lower case letter.")]
        public string Password { get; set; }

        [Display(Name = "New Password")]
        [Required(ErrorMessage = "Password can't be blank")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})", ErrorMessage = "Password should be 6 to 15 characters with at least one digit, one uppercase letter, one lower case letter.")]
        public string NewPassword { get; set; }

        [Display(Name = "Confirm New Password")]
        [Required(ErrorMessage = "Password can't be blank")]
        [RegularExpression(@"((?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,15})", ErrorMessage = "Password should be 6 to 15 characters with at least one digit, one uppercase letter, one lower case letter.")]
        public string ConfirmNewPassword { get; set; }

        [Display(Name = "Date of Joining")]
        [Required(ErrorMessage = "Date of joining can't be blank")]
        public DateTime JoiningDate { get; set; }

        [Display(Name = "Address Line 1")]
        public string AddressLine1 { get; set; }

        [Display(Name = "Address Line 2")]
        public string AddressLine2 { get; set; }
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "City should contain only alphabets")]
        public string City { get; set; }
        [RegularExpression("^[A-Za-z ]*$", ErrorMessage = "State should contain only alphabets")]
        public string State { get; set; }

        [RegularExpression("^[0-9]*$", ErrorMessage = "Please enter only numbers")]
        public string Pincode { get; set; }
        [Display(Name = "Date of Birth")]
        [Required(ErrorMessage = "Date of birth can't be blank")]
        public DateTime Birthdate { get; set; }
        public Nullable<DateTime> LastAccountModifiedDateTime { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Salary { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Bonus { get; set; }
        [RegularExpression("^[0-9.]*$", ErrorMessage = "Please enter only decimal values")]
        public Nullable<decimal> Target { get; set; }
    }
}