import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Return } from '../Models/return';
@Injectable({
  providedIn: 'root'
})

export class ReturnDetailService {
  constructor(private httpClient: HttpClient) {
  }



}
