import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import * as $ from "jquery";
import { GreatOutdoorsComponentBase } from '../../greatoutdoors-component';          
import { OrderDetail } from 'src/app/Models/order-detail';
import { Order } from 'src/app/Models/order';
import { OrderDetailsService } from '../../Services/order-details.service';
import { OrdersService } from '../../Services/orders.service';
import { Return } from 'src/app/Models/return';
import { error } from 'util';

@Component({
  selector: 'app-returns',
  templateUrl: './returns.component.html',
  styleUrls: ['./returns.component.scss']

})

export class ReturnComponent extends GreatOutdoorsComponentBase implements OnInit
{
  orders: Order[] = [];
  orderDetails: OrderDetail[] = [];
  returns = Return;

  constructor(private ordersService: OrdersService, private orderDetailsService: OrderDetailsService)
  {
    super();


  }

  ngOnInit()
  {
    this.ordersService.GetAllOrders().subscribe((response) =>
    {
      this.orders = response;

    }, (error) => {
      console.log(error);
      });

    this.orderDetailsService.GetAllOrderDetails().subscribe((response) => {
      this.orderDetails = response;

    }, (error) => {
      console.log(error);
    });

  }
  
}
