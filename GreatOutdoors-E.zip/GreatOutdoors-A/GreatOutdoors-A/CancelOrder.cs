﻿using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;
using Capgemini.GreatOutdoors.DataAccessLayer;
using Capgemini.GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Capgemini.GreatOutdoors.PresentationLayer
{
    public static class CancelOrder
    {
        public static async Task CancelRequest(Guid currRetailerID)
        {
            try
            {
                using (IOrdersBL orderAccess = new OrderBL())
                {

                    List<Order> orderHistory = await orderAccess.GetOrderByRetailerIDBL(currRetailerID);
                    //Print order history
                    Console.WriteLine("ORDERS HISTORY: ");
                    if (orderHistory != null && orderHistory?.Count > 0)
                    {
                        Console.WriteLine(".......................");
                        int serial = 0;
                        foreach (Order order in orderHistory)
                        {
                            serial++;
                            Console.WriteLine($"{serial}\t{order.OrderID}\t{order.TotalQuantity}\t{order.TotalAmount}\t{order.OrderDateTime}");
                        }
                    }
                    Console.WriteLine("Select Order to Return: ");
                    int SNo = int.Parse(Console.ReadLine()) - 1;
                    if (orderHistory[SNo].CurrentStatus != Status.Shipped || orderHistory[SNo].CurrentStatus != Status.Delivered || orderHistory[SNo].CurrentStatus != Status.Return)
                    {
                        orderHistory[SNo].CurrentStatus = Status.Cancel;
                        Console.WriteLine("Cancellation Initiated.");
                    }
                    else
                    {
                        Console.WriteLine("Cancellation Not Possible.");
                    }
                }

                



            }
            catch (GreatOutdoorsException ex)
            {
                ExceptionLogger.LogException(ex);
                Console.WriteLine(ex.Message);
            }

        }

    }
}
