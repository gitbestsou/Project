﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;


namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for ViewReturnHistory.xaml
    /// </summary>
    public partial class ViewReturnHistory : Window
    {
        public ViewReturnHistory()
        {
            InitializeComponent();
            fillData();
        }
        private async void fillData()
        {
            List<ReturnDetail> returnDetails = new List<ReturnDetail>();

            using (IReturnDetailsBL returnDetailAccess = new ReturnDetailsBL())
            {

                returnDetails = await returnDetailAccess.GetAllReturnDetailsBL();

            }

            ReturnHistory.ItemsSource = returnDetails;


        }
        private void GoBackToOrders(object sender, RoutedEventArgs e)
        {
            Window nt = new MainWindow();
            nt.Show();
            this.Close();
        }
    }
}
