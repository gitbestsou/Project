﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using GreatOutdoors.Entities;
using Capgemini.GreatOutdoors.BusinessLayer;
using Capgemini.GreatOutdoors.Contracts.BLContracts;


namespace GreatOutdoors.PresentationLayer
{
    /// <summary>
    /// Interaction logic for PlaceReturnCancel.xaml
    /// </summary>
    public partial class PlaceReturnCancel : Window
    {
        Guid OrderDetailID_function,OrderID_function;
        public PlaceReturnCancel(Guid OrderID_work,Guid OrderDetailID_here,Guid ProductID,int TotalProducts,decimal TotalAmount,string channelOfOrder)
        {
            InitializeComponent();
            OrderID_function = OrderID_work;
            FillData(ProductID, TotalProducts, TotalAmount, channelOfOrder);
            OrderDetailID_function = OrderDetailID_here;
        }
        private async void FillData(Guid ProductID, int TotalProducts, decimal TotalAmount, string channelOfOrder)
        {
            string ProductName;
            Product product = new Product();
            using (IProductBL productAccess = new ProductBL())
            {
                product = await productAccess.GetProductByProductIDBL(ProductID);
            }
            ProductName = product.Name;

            productNameBox.Text = ProductName;
            quantityBox.Text = TotalProducts.ToString();
            totalPriceBox.Text = TotalAmount.ToString();
            statusBox.Text = channelOfOrder;


        }

        private void PlaceReturn(object sender, RoutedEventArgs e)
        {
            Window nt = new SelectReturnReason(OrderID_function,OrderDetailID_function);
            nt.Show();
            this.Close();
            

        }

        private void BackToOrderDetail(object sender, RoutedEventArgs e)
        {
            Window nt = new ViewOrderDetails(OrderID_function);
            nt.Show();
            this.Close();
        }

        private async void RequestCancel(object sender, RoutedEventArgs e)
        {
            OrderDetail ordtl = new OrderDetail();
            using (IOrderDetailsBL orderDetailAccess = new OrderDetailsBL())
            {
                ordtl = await orderDetailAccess.GetOrderDetailByOrderDetailIDBL(OrderDetailID_function);
            }
            if (ordtl.CurrentStatus == "Returned")
            {
                MessageBox.Show("Product already returned");

            }
            else if (ordtl.CurrentStatus == "Cancelled")
            {
                MessageBox.Show("Product already cancelled");
            }
            else
            {
                using (IOrderDetailsBL orderDetailsBL = new OrderDetailsBL())
                {
                    if (MessageBox.Show("Do you want to confirm Cancellation?", "Cancel", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    {
                        orderDetailsBL.UpdateOrderDetailForReturn(ordtl.OrderDetailID, "Cancelled");
                        MessageBox.Show("Order cancelled");
                    }
                }
                
            }
            Window nt = new ViewOrderDetails(OrderID_function);
            nt.Show();
            this.Close();
        }


    }
}
